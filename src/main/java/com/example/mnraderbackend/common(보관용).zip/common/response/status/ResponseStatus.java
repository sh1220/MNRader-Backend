package com.example.mnraderbackend.common.response.status;

public interface ResponseStatus {

    int getCode();

    int getStatus();

    String getMessage();

}